var data =[
  {
      "navId": 1,
      "navTitle": "数学函数",
      "navUrl": "../html/test.html",
      "navParentId": 0
  }, {
      "navId": 2,
      "navTitle": "辅助证明",
      "navUrl": "../html/test.html",
      "navParentId": 0
  }, {
      "navId": 3,
      "navTitle": "幂函数",
      "navUrl": "../html/test.html",
      "navParentId": 1
  }, {
      "navId": 4,
      "navTitle": "三角函数",
      "navUrl": "../html/test1.html",
      "navParentId": 1
  }, {
      "navId": 5,
      "navTitle": "指对数函数",
      "navUrl": "../html/test2.html",
      "navParentId": 1
  }, {
      "navId": 6,
      "navTitle": "自定义函数",
      "navUrl": "../html/test3.html",
      "navParentId": 1
  }, {
      "navId": 7,
      "navTitle": "泰勒公式证明",
      "navUrl": "../html/test6.html",
      "navParentId": 2
  }, {
      "navId": 8,
      "navTitle": "极坐标",
      "navUrl": "../html/test5.html",
      "navParentId": 2
  }, {
      "navId": 9,
      "navTitle": "阿基米德螺线",
      "navUrl": "../html/test4.html",
      "navParentId": 2
  }, {
      "navId": 10,
      "navTitle": "星状图",
      "navUrl": "../html/test7.html",
      "navParentId": 2
  }
]


$(function() {
  for(var i = 0; i < data.length; i++) {
      //1.循环访问data数组中的每个对象，长度为data.length
      $.each(data[i], function(key, val) {
      //2.遍历每个data对象的键值对，key代表属性名，val代表对应的属性值
      if(data[i][key] == 0) {
        //3.判断该data对象是否存在菜单的父级菜单id为0
        //为0 则为一级菜单，生成li标签，显示菜单项名称data[i]["navTitle"]
        //同时添加li的class为data[i]["navId"]
        $("#mainbox").append("<li class='" + data[i]["navId"] + "'><span class='shead'><img src='../img/" + data[i]["navId"] + ".png' width='30px' height='30px'/></span><a>" + data[i]["navTitle"] + "</a><span class='sfoot'><img src='../img/triangle.png' width='10px' height='10px'/></span><ul></ul></li>");
        //4.页面首次加载时，只有第一项一级菜单的子菜单显示，其他子菜单项隐藏
        $("li.1").children("ul").slideDown();
        $("li.1").siblings().children("ul").slideUp();
        //6.为一级菜单绑定点击事件
        //一级菜单项可以滑动显示或隐藏子菜单项
        //同时，当前菜单显示，则其他都隐藏
        $("." + data[i]["navId"]).on("click", function() {
            $(this).children("ul").slideToggle();
            $(this).siblings().children("ul").slideUp();
        })
  }
  if(data[i][key] == i + 1) {
      //5.判断非一级菜单项
      //根据该对象的父级菜单id找li标签，成为其子菜单项
      $("." + data[i]["navParentId"]).find("ul").append("<li class='" + data[i]["navId"] + "'><a href='" + data[i]["navUrl"] + "'>" + data[i]["navTitle"] + "</a></li>");
      }
      });
      }
     //})
  });

  function plot1() {
    var func = $('input#text1').val();
    if(func==""){
      alert("请输入正确的函数");
    }
    else{
    var x = /(\s)?(\d)?x(\+|\-\d)?/;
    var y = /(\s)?(\d)?x\^2(\+(\d)?x(\+|\-\d)?)?/;
    if(x.test(func)||y.test(func)){
      functionPlot({
        target: "#root1",
        width: $('#root1').width(),
        height: $('#root1').width(),
        yAxis: {
            domain: [-5,5]
        },
        grid: true,
        data: [{
                fn: func               
            }]
      })
    }
    else{
      alert("请输入ax+b或者ax^2+bx+c");
    }
  }
}

function plot2() {
  var func = $('input#text2').val();
  if(func==""){
    alert("请输入正确的函数");
  }
  else{
  var x = /(\s)?(\d)?x\^(\d)(\+|\-\d)?/;
  if(x.test(func)){
  functionPlot({
      target: "#root2",
      width: $('#root2').width(),
      height: $('#root2').width(),
      yAxis: {
          domain: [-5,5]
      },
      grid: true,
      data: [{
              fn: func
          }
      ]
  });
   }
   else{
     alert("请输入x^a+b");
     $('input#text2').val()="";
   }
  }
}
/*$(document).ready(function () {
    plot();
});*/
$(window).resize(function () {
  plot1();
});

$(window).resize(function () {
    plot2();
});
