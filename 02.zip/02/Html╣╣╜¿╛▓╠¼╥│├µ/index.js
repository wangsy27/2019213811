var one = document.getElementById("one");
var div1 = document.getElementById("div1");
one.onmouseover=function(){
  div1.innerHTML="<br/>单周是Web程序设计实验课，双周是编译原理实验课。<br/><br/>Web程序设计课：<br/>@n520 <br/>涂新辉 <br/>编译原理实验课:<br/>@n522 <br/>杨青"
  div1.style.display="block";
  div1.style.right = "500px";
  div1.style.backgroundColor="#cf8878";
  div1.style.height="250px";
  div1.style.width="200px";
}
one.onmouseout=function(){
  div1.style.display="none";
}

var two = document.getElementById("two");
two.onmouseover=function(){
  div1.innerHTML="人工智能<br/>@n520 <br/>张连发"
  div1.style.display="block";
  div1.style.right = "600px";
  div1.style.backgroundColor="#b7d28b";
  div1.style.height="80px";
  div1.style.width="100px";
}
two.onmouseout=function(){
  div1.style.display="none";
}

var three = document.getElementById("three");
three.onmouseover=function(){
  div1.innerHTML="单周上操作系统实验课，双周上理论课。<br/><br/>操作系统实验课：<br/>@n520 <br/>李源 <br/>操作系统理论课：<br/>@n211 <br/>李源"
  div1.style.display="block";
  div1.style.right = "500px";
  div1.style.backgroundColor="#d9b8f1";
  div1.style.height="200px";
  div1.style.width="200px";
}
three.onmouseout=function(){
  div1.style.display="none";
}

var four = document.getElementById("four");
four.onmouseover=function(){
  div1.innerHTML="微机原理与接口技术：<br/>@n217 <br/>姚华雄"
  div1.style.display="block";
  div1.style.right = "600px";
  div1.style.backgroundColor="#f16d7a";
  div1.style.height="80px";
  div1.style.width="100px";
}
four.onmouseout=function(){
  div1.style.display="none";
}

var ten = document.getElementById("ten");
ten.onmouseover=function(){
  div1.innerHTML="操作系统原理：<br/>@n211 <br/>李源"
  div1.style.display="block";
  div1.style.right = "600px";
  div1.style.backgroundColor="#b7d28b";
  div1.style.height="80px";
  div1.style.width="100px";
}
ten.onmouseout=function(){
  div1.style.display="none";
}

var five = document.getElementById("five");
five.onmouseover=function(){
  div1.innerHTML="习近平新世代中国特色社会主义思想概论：<br/>@n215 <br/>张彦斌"
  div1.style.display="block";
  div1.style.right = "600px";
  div1.style.backgroundColor="#fecf45";
  div1.style.height="120px";
  div1.style.width="100px";
}
five.onmouseout=function(){
  div1.style.display="none";
}

var six = document.getElementById("six");
six.onmouseover=function(){
  div1.innerHTML="Web程序语言设计：<br/>@n108 <br/>涂新辉"
  div1.style.display="block";
  div1.style.right = "600px";
  div1.style.backgroundColor="#fecf45";
  div1.style.height="80px";
  div1.style.width="100px";
}
six.onmouseout=function(){
  div1.style.display="none";
}

var seven = document.getElementById("seven");
seven.onmouseover=function(){
  div1.innerHTML="专业英语：<br/>@n112 <br/>李增扬"
  div1.style.display="block";
  div1.style.right = "600px";
  div1.style.backgroundColor="#f16d7a";
  div1.style.height="80px";
  div1.style.width="100px";
}
seven.onmouseout=function(){
  div1.style.display="none";
}

var eight = document.getElementById("eight");
eight.onmouseover=function(){
  div1.innerHTML="单周上实验课。<br/><br/>微机原理接口与技术：<br/>@n535 <br/>姚华雄"
  div1.style.display="block";
  div1.style.right = "570px";
  div1.style.backgroundColor="#b7d28b";
  div1.style.height="150px";
  div1.style.width="120px";
}
eight.onmouseout=function(){
  div1.style.display="none";
}

var nine = document.getElementById("nine");
nine.onmouseover=function(){
  div1.innerHTML="编译原理：<br/>@n108 <br/>杨青"
  div1.style.display="block";
  div1.style.right = "600px";
  div1.style.backgroundColor="#fecf45";
  div1.style.height="80px";
  div1.style.width="100px";
}
nine.onmouseout=function(){
  div1.style.display="none";
}

var eleven = document.getElementById("eleven");
eleven.onmouseover=function(){
  div1.innerHTML="传播中的法与理：<br/>网课 <br/>MOOC"
  div1.style.display="block";
  div1.style.right = "600px";
  div1.style.backgroundColor="#f16d7a";
  div1.style.height="80px";
  div1.style.width="100px";
}
eleven.onmouseout=function(){
  div1.style.display="none";
}


