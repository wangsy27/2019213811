var data = [
  {
      class:"微机原理与接口技术",
      location:"n217",
      teacher:"姚华雄",
      weekday:1,
      number:2,
      id:"w1_j2",
      week:1
  },
  {
    class:"专业英语",
    location:"n112",
    teacher:"李增扬",
    weekday:1,
    number:4,
    id:"w1_j4",
    week:1
  },
  {
    class:"传播中的法与理",
    location:"Internet",
    teacher:"李理/陈科/黄月琴/甘丽华/张勇军",
    weekday:1,
    number:5,
    id:"w1_j5",
    week:1
  },
  {
    class:"Web程序设计实验",
    location:"n520",
    teacher:"涂新辉",
    weekday:2,
    number:1,
    id:"w2_j1",
    week:2
  },
  {
    class:"编译原理实验",
    location:"n520",
    teacher:"杨青",
    weekday:2,
    number:1,
    id:"w2_j1",
    week:3
  },
  {
    class:"人工智能",
    location:"n520",
    teacher:"张连发",
    weekday:3,
    number:1,
    id:"w3_j1",
    week:1
  },
  {
    class:"操作系统原理",
    location:"n211",
    teacher:"李源",
    weekday:3,
    number:2,
    id:"w3_j2",
    week:1
  },
  {
    class:"微机原理与操作系统实验",
    location:"n535",
    teacher:"姚华雄",
    weekday:3,
    number:3,
    id:"w3_j4",
    week:2
  },
  {
    class:"习近平新世代中国特色社会主义思想概论",
    location:"n215",
    teacher:"张艳斌",
    weekday:4,
    number:2,
    id:"w4_j2",
    week:1
  },
  {
    class:"Web程序设计",
    location:"n108",
    teacher:"涂新辉",
    weekday:4,
    number:3,
    id:"w4_j3",
    week:1
  },
  {
    class:"编译原理",
    location:"n108",
    teacher:"杨青",
    weekday:4,
    number:4,
    id:"w4_j4",
    week:1
  },
  {
    class:"操作系统原理实验",
    location:"n211",
    teacher:"李源",
    weekday:5,
    number:1,
    id:"w5_j1",
    week:1
  }
];

var color=["#f16d7a","#cb8e85","#b7d28b","#fecf45","#d9b8f1"];
//动态生成html代码，创建基本的课程表
function createTable(idName) {
  var div = $("#" + idName);    //定位上层节点div
  div.css("margin","30px auto");//表格居中，添加上下边距
  div.append('<table class="table"></table>');//添加表格
  var table = div.find(".table");
  var tr;
  for (var i = 0; i <= 6; i++) {
      if (i == 0) {
          //添加周信息
          table.append('<tr class="headCourse"><th class="th_course"></th><th class="th_course">Mon</th><th class="th_course">Tue</th><th class="th_course">Wed</th><th class="th_course">Thur</th><th class="th_course">Fri</th></tr>');         
      } 
      else {
          //添加时段信息
          //<tr class="j1"></tr>
          table.append('<tr class="j' + i + '"></tr>');
          tr = $(".j" + i);
          //<th>1</th>
          tr.append('<th class="th_course">' + i + '</th>');
          for (var j = 1; j <= 5; j++) {
              //<td id="w1_j1"></td>
              tr.append('<td id="w' + j + '_j' + i + '" class="td_course"></td>');
            }
      }
    }
  }

//获取想要的信息
function adddata(week){
  var newdata=[];
  if(week % 2==1){
    week = 2;
  }
  else{
    week = 3;
  }
  for(var i = 0 ; i< data.length;i++){
    if(data[i].week != 1 && data[i].week != week){  
      continue;
    }
    else{
        newdata.push(data[i]);
    } 
  }
  return newdata;  
}

function create(){
  var week = $("input#text").val();
  var number = parseInt(week);

  //清空上一次的数据
  for(var i = 1;i<=5;i++){
    for(var j = 1;j<=6;j++){
      var t = $("td#w"+i+"_j"+j);
      t.html("");
      t.css("backgroundColor","white");
    }
  }

  var getdata = adddata(number);

  for(var i = 0;i<getdata.length;i++){
    var t = $("td#"+getdata[i].id);
    t.text(getdata[i].class);
    t.css("backgroundColor",color[getdata[i].weekday-1]);
    t.css("color","white");
    t.css("font-weight","700");
    t.mouseenter(getdata[i],function (event) { 
      var a = $("div#dis");
      var course=event.data;
      a.css("display","block");
      a.css("right","500px");
      a.css("backgroundColor",color[course.weekday-1]);
      a.css("height","120px");
      a.css("width","100px");
      a.css("font-size","15px");
      a.css("color","white");
      a.html("课程:"+course.class+"<br>"+"教师:"+course.teacher+"<br>"+"地点"+course.location);
    });
    t.mouseleave(function () { 
      var a = $("div#dis");
      a.css("display","none");
      a.html("");
    });
  }
}